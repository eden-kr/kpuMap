package com.example.kpumap

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageButton
import android.widget.ListView
import android.widget.TextView
import java.lang.IndexOutOfBoundsException
import java.util.ArrayList

class BeerActivity : AppCompatActivity() {
    companion object {
        var beerArr = arrayListOf<beer>()
    }

    private fun LoadDB() {
        val helper = DbAdapter(this)
        helper.createDatabase()       //db생성
        helper.open()         //db복사

        beerArr = helper.GetBeerData()   //술집
        helper.close()  //닫기
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_beer)
        try {
            LoadDB()
        } catch (e: IndexOutOfBoundsException) {
            throw IndexOutOfBoundsException()
        }
        val listView : ListView = findViewById(R.id.BeerListView)
        listView.adapter = BeerView(this, beerArr)
    }
}
class BeerView(val context: Context, val beerList: ArrayList<beer>) : BaseAdapter() {

    var beerImageArray = arrayListOf<Int>(R.drawable.b1,R.drawable.b2, R.drawable.b3,R.drawable.b4,R.drawable.b5,
        R.drawable.b6,R.drawable.b7,R.drawable.b8, R.drawable.b9)

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        var view : View = LayoutInflater.from(context).inflate(R.layout.listitem, null)

        var callView: TextView = view.findViewById(R.id.list_call)     //가게 전화번호
        var addressView: TextView = view.findViewById(R.id.list_address)       //가게 주소
        var titleView: TextView = view.findViewById(R.id.list_title)       //가게에 대한 간략한 설명
        var picView: ImageButton = view.findViewById(R.id.list_picture)        //가게사진
        var nameView: TextView = view.findViewById(R.id.list_name)         //가게 이름
        val beer = beerList[position]
        callView.text = beer.beerCall
        addressView.text = beer.beerPlace
        titleView.text = beer.beerIntroduce
        nameView.text = beer.beerName
        picView.setImageResource(beerImageArray[position])

        return view
    }

    override fun getItem(position: Int): Any {
        return position
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getCount(): Int {
        return beerList.size
    }

}