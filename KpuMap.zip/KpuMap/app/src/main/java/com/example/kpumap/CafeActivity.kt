package com.example.kpumap

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageButton
import android.widget.ListView
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_cafe.*
import java.lang.IndexOutOfBoundsException
import java.util.ArrayList

class CafeActivity : AppCompatActivity() {
    companion object {
        var cafeArr = arrayListOf<cafe>()
    }

    private fun LoadDB() {
        val helper = DbAdapter(this)
        helper.createDatabase()       //db생성
        helper.open()         //db복사

        cafeArr = helper.GetCafeData()   //카페
        helper.close()  //닫기
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cafe)
        try {
            LoadDB()
        } catch (e: IndexOutOfBoundsException) {
            throw IndexOutOfBoundsException()
        }
        val cafeListView : ListView = findViewById(R.id.cafeListView)
        cafeListView.adapter = CafeView(this,cafeArr)
    }
}
class CafeView(val context: Context, val cafeList: ArrayList<cafe>) : BaseAdapter() {
    var cafeImageArray = arrayListOf<Int>(R.drawable.c1,R.drawable.c2, R.drawable.c3,R.drawable.c4,R.drawable.c5,
        R.drawable.c6,R.drawable.c7,R.drawable.c8, R.drawable.c9)

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        var view : View = LayoutInflater.from(context).inflate(R.layout.listitem, null)

        var callView: TextView = view.findViewById(R.id.list_call)     //가게 전화번호
        var addressView: TextView = view.findViewById(R.id.list_address)       //가게 주소
        var titleView: TextView = view.findViewById(R.id.list_title)       //가게에 대한 간략한 설명
        var picView: ImageButton = view.findViewById(R.id.list_picture)        //가게사진
        var nameView: TextView = view.findViewById(R.id.list_name)         //가게 이름

        val cafe = cafeList[position]
        callView.text = cafe.cafeCall
        addressView.text = cafe.cafePlace
        titleView.text = cafe.cafeIntroduce
        nameView.text = cafe.cafeName
        picView.setImageResource(cafeImageArray[position])

        return view
    }

    override fun getItem(position: Int): Any {
        return position
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getCount(): Int {
        return cafeList.size
    }

}
