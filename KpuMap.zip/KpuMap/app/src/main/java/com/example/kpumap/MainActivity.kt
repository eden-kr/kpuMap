package com.example.kpumap

import android.app.LauncherActivity
import android.content.Context
import android.content.Intent
import android.content.res.Resources
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.text.Layout
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.BaseAdapter
import android.widget.ImageButton
import android.widget.ListView
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_start.*
import java.lang.Exception
import java.lang.IndexOutOfBoundsException
import java.sql.SQLException
import java.util.ArrayList


class MainActivity : AppCompatActivity() {

    var searchText: String? = null

    //static
    companion object {
        var storeArr = arrayListOf<store>()
    }

    private fun LoadDB() {
        val helper = DbAdapter(this)
        helper.createDatabase()       //db생성
        helper.open()         //db복사

        storeArr = helper.GetAllData()      //모든 객체 가져오기
        helper.close()  //닫기
    }

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        try {
            LoadDB()
            //  convert()
        } catch (e: IndexOutOfBoundsException) {
            throw IndexOutOfBoundsException()
        }

        //Log.d("myTag", "카페 명은  " + cafeArr[0].cafeName + cafeArr[0].cafeIntroduce)
        //Log.d("myTag", "술집소개! " + beerArr[0].beerName + beerArr[0].beerIntroduce)
        //Log.d("myTag", "길이"+resArr.size)
        //Log.d("myTag",packageName.toString())
        /*
        for(i in 0..storeArr.size-1) {
            Log.d("myTag", storeArr[i].storeName)
        }*/

        //검색어 가져오기
        searchText = searchEdit.text.toString()
        //돋보기 클릭 시 검색 한 가게 액티비티 실행
        searchBtn.setOnClickListener {
            for (i in 0..storeArr.size - 1) {
                if (storeArr[i].storeName.equals(searchText)) {
                    //클릭시 가게명 액티비티를 실행
                    var str = searchText + "Activity"
                    val intent = Intent(this, str::class.java)
                    startActivity(intent)
                }
            }
        }
        val mainList: ListView = findViewById(R.id.mainListView)
        mainList.adapter = mainList(this, storeArr)

        //맵 버튼 클릭 시 지도 보여주기
        mapButton.setOnClickListener {

        }
        //이미지 클릭시 RestaurantActivity 인텐트 보내기
        restaurant.setOnClickListener {
            val intent = Intent(this, RestaurantActivity::class.java)
            startActivity(intent)
        }
        //술집 리스트 액티비티 실행
        beer.setOnClickListener {
            val intent = Intent(this, BeerActivity::class.java)
            startActivity(intent)
        }
        //카페 리스트 액티비티 실행
        cafe.setOnClickListener {
            val intent = Intent(this, CafeActivity::class.java)
            startActivity(intent)
        }
    }
}

//메인 리스트뷰 생성
class mainList(val context: Context, val storeList: ArrayList<store>) : BaseAdapter() {

    //getidentifier 사용해도 됌
    var storeImageArray = arrayListOf<Int>(
        R.drawable.c1, R.drawable.c2, R.drawable.c3, R.drawable.c4, R.drawable.c5,
        R.drawable.c6, R.drawable.c7, R.drawable.c8, R.drawable.c9, R.drawable.b1, R.drawable.b2,
        R.drawable.b3, R.drawable.b4, R.drawable.b5, R.drawable.b6, R.drawable.b7, R.drawable.b8,
        R.drawable.b9, R.drawable.r1, R.drawable.r2, R.drawable.r3, R.drawable.r4, R.drawable.r5,
        R.drawable.r6, R.drawable.r7, R.drawable.r8, R.drawable.r9, R.drawable.r10,
        R.drawable.r11, R.drawable.r12, R.drawable.r13
    )


    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {


        var view: View = LayoutInflater.from(context).inflate(R.layout.listitem, null)

        var callView: TextView = view.findViewById(R.id.list_call)     //가게 전화번호
        var addressView: TextView = view.findViewById(R.id.list_address)       //가게 주소
        var titleView: TextView = view.findViewById(R.id.list_title)       //가게에 대한 간략한 설명
        var picView: ImageButton = view.findViewById(R.id.list_picture)        //가게사진
        var nameView: TextView = view.findViewById(R.id.list_name)         //가게 이름

        val store = storeList[position]
        nameView.text = store.storeName
        callView.text = store.storeCall
        addressView.text = store.storePlace
        titleView.text = store.storeIntro
        picView.setImageResource(storeImageArray[position])

        return view
    }

    override fun getItem(position: Int): Any {
        return position
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getCount(): Int {
        return storeList.size
    }

}


