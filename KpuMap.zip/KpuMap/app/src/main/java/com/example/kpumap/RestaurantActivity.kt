package com.example.kpumap

import android.app.ActionBar
import android.app.Activity
import android.content.Context
import android.media.Image
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import kotlinx.android.synthetic.main.activity_restaurant.*
import org.w3c.dom.Text
import java.lang.IndexOutOfBoundsException
import java.lang.NullPointerException
import java.util.ArrayList



class RestaurantActivity : AppCompatActivity() {

    companion object {
        var resArr = arrayListOf<restaurant>()
    }

    private fun LoadDB() {
        val helper = DbAdapter(this)
        helper.createDatabase()       //db생성
        helper.open()         //db복사

        resArr = helper.GetResData()    //레스토랑
        helper.close()  //닫기
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_restaurant)

        try {
            LoadDB()
        } catch (e: IndexOutOfBoundsException) {
            throw IndexOutOfBoundsException()
        }

        val listView: ListView = findViewById(R.id.listView)
        listView.adapter = CustomView(this, resArr)

        //뒤로 가기 버튼
        val toolbar:Toolbar = findViewById(R.id.resToolBar)
        this.setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)   //툴바에 홈 추가
        supportActionBar?.setHomeAsUpIndicator(R.drawable.backbutton)   //백버튼 설정

    }
}

class CustomView(val context: Context, val resList: ArrayList<restaurant>) : BaseAdapter() {

    private var myInflater: LayoutInflater? = null

    //사진 배열
    val imageArray = arrayListOf<Int>(
        R.drawable.r1, R.drawable.r2, R.drawable.r3, R.drawable.r4, R.drawable.r5,
        R.drawable.r6, R.drawable.r7, R.drawable.r8, R.drawable.r9, R.drawable.r10,
        R.drawable.r11, R.drawable.r12, R.drawable.r13
    )

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            var view : View = LayoutInflater.from(context).inflate(R.layout.listitem, null)

            var callView: TextView = view.findViewById(R.id.list_call)     //가게 전화번호
            var addressView: TextView = view.findViewById(R.id.list_address)       //가게 주소
            var titleView: TextView = view.findViewById(R.id.list_title)       //가게에 대한 간략한 설명
            var picView: ImageButton = view.findViewById(R.id.list_picture)        //가게사진
            var nameView: TextView = view.findViewById(R.id.list_name)         //가게 이름
            val restaurant = resList[position]
            callView.text = restaurant.resCall
            addressView.text = restaurant.resPlace
            titleView.text = restaurant.resIntroduce
            nameView.text = restaurant.resName
            picView.setImageResource(imageArray[position])


        return view
    }

    override fun getItem(position: Int): Any {
        return resList[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()     //중요함 구현해야함
    }

    override fun getCount(): Int {
        return resList.size
    }


}


