package com.example.kpumap

open class beer(
    var id: Int,
    var beerName: String,
    var beerPlace: String,
    var beerCall: String,
    var beerIntroduce: String
) {}

open class restaurant(
    var id: Int,
    var resPlace: String,
    var resCall: String,
    var resIntroduce: String,
    var resName: String
) {}

open class cafe(
    var id: Int,
    var cafeName: String,
    var cafePlace: String,
    var cafeCall: String,
    var cafeIntroduce: String
) {}
open class store(
    var storeName : String,
    var storePlace : String,
    var storeCall : String,
    var storeIntro : String
){}
